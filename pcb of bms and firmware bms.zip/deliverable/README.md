# STM32 ⇄ Daly BMS (CAN) ⇄ ESP32 (UART) — Electronics assignment

Both questions are attempted. Layout:

```
pcb/        Q1  KiCad 7 project (schematic + PCB), gerbers/drill, schematic.pdf, pcb_layout.pdf, pcb_top_view.png
firmware/   Q2  STM32F103 firmware (can_driver / bms_protocol / esp_link / main), Makefile, host unit tests
bms_bridge_firmware.bin   pre-built image of the firmware (6.6 kB flash)
```

---------------------------------------------------------------------

## Q1 – PCB

**MCU:** STM32F103C8T6 (LQFP-48, has bxCAN). **Radio:** ESP32-WROOM-32E module on the board.
**Board:** 110 × 75 mm, 2 layers, solid GND pour on both sides, 4 × M3 holes.

| Block | Implementation |
|---|---|
| Power | 5 V screw terminal J1 → SS14 reverse-polarity diode → AMS1117-3.3 (10 µF in, 22 µF tantalum out, 100 nF each side). Everything runs from the single 3.3 V rail. Green power LED. |
| STM32 | 8 MHz crystal + 2×20 pF, 4 × 100 nF on VDD pins + 10 µF bulk, VDDA 1 µF + 100 nF, BOOT0 10 k pull-down + jumper JP1 to 3V3, BOOT1 pull-down, status LED on PC13 (via 1 k). |
| Reset | SW1 push-button, 10 k pull-up, 100 nF to GND on NRST (also on SWD header). |
| SWD | J3 1×5 header: 3V3, SWDIO, SWCLK, NRST, GND. |
| CAN | SN65HVD230 (3.3 V transceiver) on PA11/PA12, 120 Ω termination switchable with jumper JP2, 3-way terminal J2 (CANH / CANL / GND), Rs pin to GND through 10 k (slope control). |
| ESP32 link | STM32 USART2 PA2 (TX) → ESP32 IO16 (UART2 RX); ESP32 IO17 (UART2 TX) → STM32 PA3 (RX). Both 3.3 V, no level shifter needed. |
| ESP32 support | EN pull-up 10 k + 1 µF, IO0 pull-up + BOOT button SW3, EN button SW2, 10 µF + 100 nF decoupling, J5 header (GND, TX0, RX0) for flashing the ESP32 with a USB-serial adapter. |
| Extras | USART1 debug header J6 (PA9/PA10). |

**Checks (KiCad 7.0 default rules, run headless):**
* ERC: **0 errors, 0 warnings.**
* DRC (incl. schematic-parity): **0 errors, 0 unconnected items.** One *warning* remains: `lib_footprint_mismatch` on U2 — I deleted the ESP32 footprint's 0.2 mm thermal-via pads (they are below KiCad's default 0.3 mm minimum drill and would be DRC errors) and added 0.3 mm GND vias instead.
* Routing was done with Freerouting, then GND-plane islands were stitched to the opposite layer with extra vias so the pour is one electrical net.

Open `pcb/bms_can_bridge.kicad_pro`. Fabrication files are in `pcb/gerbers/`.

**Limitations/notes (honest list):**
* The board has not been fabricated or powered; it is verified by ERC/DRC and by reading the netlist, not by bench test.
* The ESP32 antenna end sits at the board edge with a copper keep-out, as the module datasheet asks.
* Autorouted layout – fine for 250 kbit/s CAN and 115200 UART, but not hand-optimised; the crystal is placed close to the MCU, decoupling caps next to each VDD pin.
* The AMS1117 is chosen for availability; ESP32 peaks (~500 mA) are within its 1 A rating, but its dropout from a 5 V rail is only ~1.3 V, so the 5 V input should not sag below ~4.6 V.
* BMS CAN lines are not galvanically isolated (the assignment did not ask for it). For a real pack, an isolated transceiver is advisable.

---------------------------------------------------------------------

## Q2 – Firmware

### Structure (modular as requested)
| File | Role |
|---|---|
| `src/can_driver.c/.h` | bxCAN driver only: 250 kbit/s, 29-bit extended IDs, hardware filter on the reply ID, send / receive / flush / abort. No Daly knowledge. |
| `src/bms_protocol.c/.h` | Daly Data-ID 0x90: builds request `0x18900140` (8 × 0x00), decodes reply `0x18904001`, plus a non-blocking query state machine with the 500 ms timeout and retry. Talks only to `can_driver.h`. |
| `src/esp_link.c/.h` | USART2 115200 8N1 to the ESP32 and the JSON line formatter (integer maths only, no float printf). |
| `src/main.c` | Application: 1 s cycle, failure counting, LED, watchdog, clock setup. |

### Behaviour
* CAN bit timing: APB1 36 MHz, prescaler 9, 1+13+2 = 16 tq → **250 kbit/s**, sample point 87.5 %.
* Every 1 s: send request → wait up to **500 ms** → if no reply, **retry once** (so 2 attempts, up to 1 s).
* Reply decoded: `voltage = raw16(B0..B1) × 0.1 V`, `current = (raw16(B4..B5) − 30000) × 0.1 A`.
* Output line, one per second, e.g. `{"voltage":53.2, "current":-12.3}` + `\n`.
* After **3 consecutive failed cycles** (= 6 unanswered requests, ~3 s) it sends `{"error":"bms_timeout"}` every second until the BMS answers again; one good reply resets the counter. (Constants `BMS_RETRIES`, `APP_FAIL_CYCLES_BEFORE_ERROR`.)
* Independent watchdog (~2 s) restarts the MCU if the main loop ever hangs.

### Build / test
```
git clone https://github.com/STMicroelectronics/stm32f1xx_hal_driver deps/stm32f1xx_hal_driver
git clone https://github.com/STMicroelectronics/cmsis_device_f1      deps/cmsis_device_f1
git clone https://github.com/ARM-software/CMSIS_5                    deps/CMSIS_5   # only CMSIS/Core is used
cd firmware
make          # arm-none-eabi-gcc -> build/bms_bridge.elf/.bin   (or override HAL_DIR=… CMSIS_DEV_DIR=… CMSIS_CORE_DIR=…)
make test     # host unit tests, gcc only
```
Results here: firmware builds without warnings (text 6600 B, bss 1708 B) and **39/39 host checks pass**. The tests cover the spec's worked example (`02 14 02 12 75 30 03 E8` → 53.2 V / 0.0 A), the −50.0 A case (raw 29500), wrong ID/DLC rejection, JSON formatting incl. negative and sub-1 values, first-try success, success on retry, and timeout after retry — all against a mock CAN driver.
**Not tested on real hardware** (no BMS/STM32 was available); on-target behaviour is by code review and the host tests.

### Assumptions (where the protocol sheet is unclear)
1. **Byte order:** 16-bit fields are big-endian (high byte first). The sheet says "assumed"; it is consistent with the worked example (0x0214 = 532 → 53.2 V).
2. **Which "total voltage":** the sheet lists *cumulative total voltage* (bytes 0-1) and *gather total voltage* (bytes 2-3). I report **bytes 0-1 (cumulative)** as the pack voltage. Build with `-DBMS_VOLTAGE_SOURCE=1` to use bytes 2-3 instead; compare with a multimeter on the pack and pick the matching one.
3. **Current sign:** `(raw − 30000) × 0.1 A` is sent as-is. Whether negative means charge or discharge is not stated in the sheet; the example in the task (−12.3 A) is passed through unchanged. Verify on the real pack.
4. **Request data:** 8 bytes of 0x00, DLC = 8, extended ID, as specified.
5. **Reply ID** is exactly `0x18904001`; all other IDs are ignored (hardware filter + software check). SOC (bytes 6-7) is decoded but not transmitted.
6. **Hardware:** STM32F103C8 with 8 MHz HSE (72 MHz core), CAN1 on default pins PA11/PA12, USART2 on PA2/PA3 – matching the schematic. A CAN transceiver is required on the bus; the BMS side must provide a termination (the board has a switchable 120 Ω).
7. "Repeated failures" = 3 consecutive 1 s cycles, each with one retry (see above). Chosen so a single dropped frame never produces an error line.
8. The error line is sent **instead of** a data line; a line is never sent from stale data.
9. JSON uses one decimal and the exact spacing of the example (`, ` between fields); the line ends with `\n`.
10. Polling is 1 Hz as given; the BMS never sends this data by itself, so the STM32 must poll.
