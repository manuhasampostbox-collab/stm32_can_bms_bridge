/**
 * main.c - application: poll the BMS once per second, forward to the ESP32.
 *
 * Every 1000 ms a "cycle" starts:
 *   - send request 0x18900140, wait up to 500 ms, retry once   (bms_protocol)
 *   - reply received  -> send {"voltage":53.2, "current":-12.3}
 *   - both attempts failed -> count a failed cycle; after
 *     APP_FAIL_CYCLES_BEFORE_ERROR consecutive failed cycles send
 *     {"error":"bms_timeout"} (and keep sending it every second while the
 *     BMS stays silent). One good reply clears the counter.
 * At most one line goes to the ESP32 per second.
 */
#include "stm32f1xx_hal.h"
#include "can_driver.h"
#include "bms_protocol.h"
#include "esp_link.h"

#define APP_PERIOD_MS               1000u
#define APP_FAIL_CYCLES_BEFORE_ERROR 3u

static IWDG_HandleTypeDef hiwdg;

static void SystemClock_Config(void);
static void Error_Handler(void);
static void led_init(void);

int main(void)
{
    HAL_Init();
    SystemClock_Config();          /* HSE 8 MHz -> PLL x9 = 72 MHz, APB1 = 36 MHz */
    led_init();

    if (!esp_link_init())                         Error_Handler();
    if (can_driver_init(BMS_RESPONSE_ID) != CAN_DRV_OK) Error_Handler();

    /* Watchdog ~2 s (LSI 40 kHz / 64 * 1250) */
    hiwdg.Instance       = IWDG;
    hiwdg.Init.Prescaler = IWDG_PRESCALER_64;
    hiwdg.Init.Reload    = 1250;
    if (HAL_IWDG_Init(&hiwdg) != HAL_OK)          Error_Handler();

    uint32_t next_cycle_ms = HAL_GetTick();
    uint8_t  failed_cycles = 0;
    bool     query_active  = false;
    char     line[ESP_LINK_LINE_MAX];

    for (;;) {
        uint32_t now = HAL_GetTick();
        HAL_IWDG_Refresh(&hiwdg);

        /* start a new cycle on the 1 s grid (wrap-safe compare) */
        if (!query_active && (int32_t)(now - next_cycle_ms) >= 0) {
            next_cycle_ms += APP_PERIOD_MS;
            bms_query_start(now);
            query_active = true;
        }

        if (query_active) {
            bms_reading_t r;
            bms_query_state_t s = bms_query_poll(now, &r);

            if (s == BMS_QUERY_DONE) {
                failed_cycles = 0;
                size_t n = esp_link_format_data(line, sizeof line, r.voltage_dv, r.current_da);
                if (n) esp_link_send(line, n);
                HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);   /* heartbeat on good data */
                query_active = false;
            } else if (s == BMS_QUERY_TIMEOUT) {
                if (failed_cycles < 255u) failed_cycles++;
                if (failed_cycles >= APP_FAIL_CYCLES_BEFORE_ERROR) {
                    size_t n = esp_link_format_timeout(line, sizeof line);
                    if (n) esp_link_send(line, n);
                }
                query_active = false;
            }
        }
    }
}

/* PC13 status LED (on the PCB, active low) */
static void led_init(void)
{
    GPIO_InitTypeDef g = {0};
    __HAL_RCC_GPIOC_CLK_ENABLE();
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
    g.Pin = GPIO_PIN_13; g.Mode = GPIO_MODE_OUTPUT_PP; g.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOC, &g);
}

static void SystemClock_Config(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};

    osc.OscillatorType = RCC_OSCILLATORTYPE_HSE | RCC_OSCILLATORTYPE_LSI;
    osc.HSEState       = RCC_HSE_ON;
    osc.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
    osc.LSIState       = RCC_LSI_ON;
    osc.PLL.PLLState   = RCC_PLL_ON;
    osc.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
    osc.PLL.PLLMUL     = RCC_PLL_MUL9;
    if (HAL_RCC_OscConfig(&osc) != HAL_OK) Error_Handler();

    clk.ClockType      = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK |
                         RCC_CLOCKTYPE_PCLK1  | RCC_CLOCKTYPE_PCLK2;
    clk.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    clk.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    clk.APB1CLKDivider = RCC_HCLK_DIV2;     /* 36 MHz: CAN + USART2 */
    clk.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_2) != HAL_OK) Error_Handler();
}

/* Fatal init error: fast-blink the LED forever (if the IWDG is already running it resets us) */
static void Error_Handler(void)
{
    __disable_irq();
    for (;;) {
        HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
        for (volatile uint32_t i = 0; i < 400000; i++) { }
    }
}
