/**
 * bms_protocol.c - Daly BMS Data ID 0x90 request / reply handling.
 *
 * Reply layout (all 16-bit fields big-endian, i.e. high byte first - assumed,
 * the sheet does not say; this matches the worked example 02 14 -> 53.2 V):
 *   B0-1  cumulative total voltage  0.1 V/count
 *   B2-3  gather total voltage      0.1 V/count
 *   B4-5  current                   (raw - 30000) * 0.1 A
 *   B6-7  SOC                       0.1 %/count
 */
#include "bms_protocol.h"
#include <string.h>

static inline uint16_t be16(const uint8_t *p)
{
    return (uint16_t)(((uint16_t)p[0] << 8) | p[1]);
}

void bms_build_request(can_frame_t *frame)
{
    frame->ext_id = BMS_REQUEST_ID;
    frame->dlc    = 8;
    memset(frame->data, 0x00, CAN_DRV_MAX_DLC);
}

bool bms_decode_0x90(const can_frame_t *frame, bms_reading_t *out)
{
    if (frame == NULL || out == NULL) return false;
    if (frame->ext_id != BMS_RESPONSE_ID || frame->dlc != 8) return false;

    const uint8_t *d = frame->data;
#if BMS_VOLTAGE_SOURCE == 0
    out->voltage_dv = (int32_t)be16(&d[0]);
#else
    out->voltage_dv = (int32_t)be16(&d[2]);
#endif
    out->current_da = (int32_t)be16(&d[4]) - BMS_CURRENT_OFFSET;
    out->soc_pm     = be16(&d[6]);
    return true;
}

/* ---------------- query state machine ---------------- */

static struct {
    bms_query_state_t state;
    uint32_t sent_at_ms;
    uint8_t  attempts_left;     /* attempts still allowed after the current one */
} q;

static void send_request(uint32_t now_ms)
{
    can_frame_t req;
    bms_build_request(&req);
    can_driver_abort_tx();       /* drop a previous un-ACKed request, if any */
    can_driver_flush_rx();       /* a late reply to an old request must not count */
    (void)can_driver_send(&req); /* if this fails the timeout below covers it */
    q.sent_at_ms = now_ms;
}

void bms_query_start(uint32_t now_ms)
{
    q.state         = BMS_QUERY_PENDING;
    q.attempts_left = BMS_RETRIES;
    send_request(now_ms);
}

bms_query_state_t bms_query_poll(uint32_t now_ms, bms_reading_t *out)
{
    if (q.state != BMS_QUERY_PENDING) {
        return q.state;
    }

    can_frame_t rx;
    while (can_driver_receive(&rx)) {
        if (bms_decode_0x90(&rx, out)) {
            q.state = BMS_QUERY_DONE;
            return q.state;
        }
        /* anything else: ignore and keep waiting */
    }

    if ((uint32_t)(now_ms - q.sent_at_ms) >= BMS_REPLY_TIMEOUT_MS) {
        if (q.attempts_left > 0u) {
            q.attempts_left--;
            send_request(now_ms);            /* retry */
        } else {
            can_driver_abort_tx();
            q.state = BMS_QUERY_TIMEOUT;
        }
    }
    return q.state;
}
