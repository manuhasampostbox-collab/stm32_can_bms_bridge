/**
 * can_driver.c - bxCAN driver, STM32F103 (HAL).
 *
 * Bit timing @ APB1 = 36 MHz:
 *   prescaler 9  -> 4 MHz time-quantum clock
 *   1 + BS1(13) + BS2(2) = 16 tq  -> 4 MHz / 16 = 250 kbit/s
 *   sample point = (1 + 13) / 16 = 87.5 %,  SJW = 1 tq
 * Pins: PA11 = CAN_RX, PA12 = CAN_TX (default mapping, to the CAN transceiver).
 */
#include "can_driver.h"
#include "stm32f1xx_hal.h"
#include <string.h>

static CAN_HandleTypeDef hcan;

can_status_t can_driver_init(uint32_t rx_id)
{
    GPIO_InitTypeDef gpio = {0};

    __HAL_RCC_CAN1_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_AFIO_CLK_ENABLE();

    gpio.Pin  = GPIO_PIN_11;                 /* CAN_RX */
    gpio.Mode = GPIO_MODE_INPUT;
    gpio.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(GPIOA, &gpio);

    gpio.Pin   = GPIO_PIN_12;                /* CAN_TX */
    gpio.Mode  = GPIO_MODE_AF_PP;
    gpio.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &gpio);

    hcan.Instance                  = CAN1;
    hcan.Init.Prescaler            = 9;
    hcan.Init.Mode                 = CAN_MODE_NORMAL;
    hcan.Init.SyncJumpWidth        = CAN_SJW_1TQ;
    hcan.Init.TimeSeg1             = CAN_BS1_13TQ;
    hcan.Init.TimeSeg2             = CAN_BS2_2TQ;
    hcan.Init.TimeTriggeredMode    = DISABLE;
    hcan.Init.AutoBusOff           = ENABLE;   /* recover from bus-off by itself */
    hcan.Init.AutoWakeUp           = DISABLE;
    hcan.Init.AutoRetransmission   = ENABLE;   /* keep trying until ACKed / aborted */
    hcan.Init.ReceiveFifoLocked    = DISABLE;  /* newest frame overwrites oldest */
    hcan.Init.TransmitFifoPriority = ENABLE;   /* send in request order */
    if (HAL_CAN_Init(&hcan) != HAL_OK) {
        return CAN_DRV_ERR_INIT;
    }

    /* One 32-bit mask filter: accept only the exact extended ID rx_id.
     * 32-bit layout: [31:3] = EXTID, bit2 = IDE, bit1 = RTR. */
    CAN_FilterTypeDef f = {0};
    uint32_t id   = (rx_id << 3) | CAN_ID_EXT;           /* CAN_ID_EXT = 0x4 */
    uint32_t mask = (0x1FFFFFFFUL << 3) | 0x4u | 0x2u;   /* match ID, IDE and RTR=0 */
    f.FilterBank           = 0;
    f.FilterMode           = CAN_FILTERMODE_IDMASK;
    f.FilterScale          = CAN_FILTERSCALE_32BIT;
    f.FilterIdHigh         = (uint16_t)(id >> 16);
    f.FilterIdLow          = (uint16_t)(id & 0xFFFFu);
    f.FilterMaskIdHigh     = (uint16_t)(mask >> 16);
    f.FilterMaskIdLow      = (uint16_t)(mask & 0xFFFFu);
    f.FilterFIFOAssignment = CAN_RX_FIFO0;
    f.FilterActivation     = ENABLE;
    f.SlaveStartFilterBank = 14;
    if (HAL_CAN_ConfigFilter(&hcan, &f) != HAL_OK) {
        return CAN_DRV_ERR_INIT;
    }

    if (HAL_CAN_Start(&hcan) != HAL_OK) {
        return CAN_DRV_ERR_INIT;
    }
    return CAN_DRV_OK;
}

can_status_t can_driver_send(const can_frame_t *frame)
{
    if (frame == NULL || frame->dlc > CAN_DRV_MAX_DLC || frame->ext_id > 0x1FFFFFFFUL) {
        return CAN_DRV_ERR_ARG;
    }
    if (HAL_CAN_GetTxMailboxesFreeLevel(&hcan) == 0u) {
        return CAN_DRV_ERR_BUSY;
    }

    CAN_TxHeaderTypeDef hdr = {0};
    hdr.ExtId = frame->ext_id;
    hdr.IDE   = CAN_ID_EXT;
    hdr.RTR   = CAN_RTR_DATA;
    hdr.DLC   = frame->dlc;
    hdr.TransmitGlobalTime = DISABLE;

    uint32_t mailbox;
    uint8_t  data[CAN_DRV_MAX_DLC];
    memcpy(data, frame->data, sizeof data);
    return (HAL_CAN_AddTxMessage(&hcan, &hdr, data, &mailbox) == HAL_OK)
               ? CAN_DRV_OK : CAN_DRV_ERR_HAL;
}

bool can_driver_receive(can_frame_t *frame)
{
    if (HAL_CAN_GetRxFifoFillLevel(&hcan, CAN_RX_FIFO0) == 0u) {
        return false;
    }
    CAN_RxHeaderTypeDef hdr;
    if (HAL_CAN_GetRxMessage(&hcan, CAN_RX_FIFO0, &hdr, frame->data) != HAL_OK) {
        return false;
    }
    if (hdr.IDE != CAN_ID_EXT || hdr.RTR != CAN_RTR_DATA) {
        return false;                    /* cannot happen with the filter, belt and braces */
    }
    frame->ext_id = hdr.ExtId;
    frame->dlc    = (uint8_t)hdr.DLC;
    return true;
}

void can_driver_flush_rx(void)
{
    can_frame_t dummy;
    while (can_driver_receive(&dummy)) { /* discard */ }
}

void can_driver_abort_tx(void)
{
    HAL_CAN_AbortTxRequest(&hcan, CAN_TX_MAILBOX0 | CAN_TX_MAILBOX1 | CAN_TX_MAILBOX2);
}
