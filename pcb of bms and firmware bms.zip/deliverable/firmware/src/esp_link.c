/**
 * esp_link.c - UART2 (PA2 TX / PA3 RX) to the ESP32, 115200 8N1, plus the
 * integer-only JSON line formatter.
 */
#include "esp_link.h"
#ifndef ESP_LINK_HOST_TEST
#include "stm32f1xx_hal.h"
#endif
#include <string.h>

/* ---------- formatting ---------- */

/* Append a value given in tenths as [-]I.F. Returns new write index, or 0 on overflow. */
static size_t put_tenths(char *buf, size_t size, size_t i, int32_t v)
{
    uint32_t mag = (v < 0) ? (uint32_t)(-(int64_t)v) : (uint32_t)v;
    char tmp[12];
    size_t n = 0;
    uint32_t ip = mag / 10u, fp = mag % 10u;

    if (v < 0) { if (i + 1 >= size) return 0; buf[i++] = '-'; }
    do { tmp[n++] = (char)('0' + ip % 10u); ip /= 10u; } while (ip);
    if (i + n + 2 >= size) return 0;
    while (n) buf[i++] = tmp[--n];
    buf[i++] = '.';
    buf[i++] = (char)('0' + fp);
    return i;
}

static size_t put_str(char *buf, size_t size, size_t i, const char *s)
{
    size_t l = strlen(s);
    if (i == 0 || i + l >= size) return 0;
    memcpy(&buf[i], s, l);
    return i + l;
}

size_t esp_link_format_data(char *buf, size_t size, int32_t voltage_dv, int32_t current_da)
{
    size_t i = 0;
    if (size < 2) return 0;
    buf[i++] = '{';
    if (!(i = put_str(buf, size, i, "\"voltage\":")))           return 0;
    if (!(i = put_tenths(buf, size, i, voltage_dv)))            return 0;
    if (!(i = put_str(buf, size, i, ", \"current\":")))         return 0;
    if (!(i = put_tenths(buf, size, i, current_da)))            return 0;
    if (!(i = put_str(buf, size, i, "}\n")))                    return 0;
    buf[i] = '\0';
    return i;
}

size_t esp_link_format_timeout(char *buf, size_t size)
{
    static const char msg[] = "{\"error\":\"bms_timeout\"}\n";
    if (size < sizeof msg) return 0;
    memcpy(buf, msg, sizeof msg);
    return sizeof msg - 1;
}

/* ---------- hardware ---------- */

#ifndef ESP_LINK_HOST_TEST
static UART_HandleTypeDef huart2;

bool esp_link_init(void)
{
    GPIO_InitTypeDef gpio = {0};
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_USART2_CLK_ENABLE();

    gpio.Pin   = GPIO_PIN_2;                 /* USART2_TX -> ESP32 GPIO16 (U2RXD) */
    gpio.Mode  = GPIO_MODE_AF_PP;
    gpio.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &gpio);
    gpio.Pin   = GPIO_PIN_3;                 /* USART2_RX <- ESP32 GPIO17 (U2TXD) */
    gpio.Mode  = GPIO_MODE_INPUT;
    gpio.Pull  = GPIO_PULLUP;
    HAL_GPIO_Init(GPIOA, &gpio);

    huart2.Instance          = USART2;
    huart2.Init.BaudRate     = ESP_LINK_BAUD;
    huart2.Init.WordLength   = UART_WORDLENGTH_8B;
    huart2.Init.StopBits     = UART_STOPBITS_1;
    huart2.Init.Parity       = UART_PARITY_NONE;
    huart2.Init.Mode         = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    return HAL_UART_Init(&huart2) == HAL_OK;
}

bool esp_link_send(const char *line, size_t len)
{
    /* ~40 bytes @ 115200 = ~3.5 ms; 50 ms timeout is generous */
    return HAL_UART_Transmit(&huart2, (uint8_t *)line, (uint16_t)len, 50) == HAL_OK;
}
#endif
