/**
 * esp_link.h - UART link to the ESP32 (115200 8N1) + JSON line formatting.
 */
#ifndef ESP_LINK_H
#define ESP_LINK_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#define ESP_LINK_BAUD        115200u
#define ESP_LINK_LINE_MAX    64u    /* longest line incl. "\n" and NUL, see tests */

/* ---- pure formatting (no hardware, unit-tested) ---- */

/**
 * {"voltage":53.2, "current":-12.3}\n   (values given in 0.1 units)
 * Returns the number of characters written (without NUL), 0 if buf too small.
 * Done with integers only: no float printf needed, so newlib-nano is enough.
 */
size_t esp_link_format_data(char *buf, size_t size, int32_t voltage_dv, int32_t current_da);

/** {"error":"bms_timeout"}\n */
size_t esp_link_format_timeout(char *buf, size_t size);

/* ---- hardware ---- */
bool esp_link_init(void);
bool esp_link_send(const char *line, size_t len);

#endif /* ESP_LINK_H */
