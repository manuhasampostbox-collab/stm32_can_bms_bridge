/**
 * bms_protocol.h - Daly BMS "Data ID 0x90" (total voltage / current / SOC).
 *
 * Split into two layers:
 *   1. Pure helpers (bms_decode_0x90, bms_build_request) - no hardware, unit-tested.
 *   2. A small non-blocking query state machine (bms_query_*) that sends the
 *      request, waits for the reply with a timeout and retries.
 */
#ifndef BMS_PROTOCOL_H
#define BMS_PROTOCOL_H

#include <stdint.h>
#include <stdbool.h>
#include "can_driver.h"

/* ---- Protocol constants (from BMS_CAN_Voltage_Current_Protocol.xlsx) ---- */
#define BMS_REQUEST_ID          0x18900140UL  /* host 0x40 -> BMS 0x01, Data ID 0x90 */
#define BMS_RESPONSE_ID         0x18904001UL  /* BMS 0x01 -> host 0x40               */
#define BMS_CURRENT_OFFSET      30000         /* raw counts, 0.1 A / count           */

/* ---- Tunables ---- */
#define BMS_REPLY_TIMEOUT_MS    500u   /* per attempt                                */
#define BMS_RETRIES             1u     /* extra attempts after the first one         */

/*
 * Which of the two "total voltage" fields is reported as the pack voltage.
 * 0 = bytes 0-1 "cumulative total voltage"  (default; the pack/terminal voltage)
 * 1 = bytes 2-3 "gather total voltage"      (sum of cell voltages as collected)
 * The sheet does not say which one the task wants, see README "Assumptions".
 */
#ifndef BMS_VOLTAGE_SOURCE
#define BMS_VOLTAGE_SOURCE      0
#endif

typedef struct {
    int32_t voltage_dv;   /* total voltage in 0.1 V units  (532  = 53.2 V)  */
    int32_t current_da;   /* current in 0.1 A units, signed (-123 = -12.3 A) */
    uint16_t soc_pm;      /* SOC in 0.1 % (decoded for completeness, unused) */
} bms_reading_t;

/* ---------- pure helpers ---------- */

/** Fill the 8-byte all-zero request frame with ID BMS_REQUEST_ID. */
void bms_build_request(can_frame_t *frame);

/**
 * Decode a 0x90 reply. Returns false (and leaves *out untouched) if the frame
 * is not a valid reply (wrong ID or DLC != 8).
 */
bool bms_decode_0x90(const can_frame_t *frame, bms_reading_t *out);

/* ---------- non-blocking query state machine ---------- */

typedef enum {
    BMS_QUERY_IDLE = 0,
    BMS_QUERY_PENDING,   /* waiting for reply (call bms_query_poll again) */
    BMS_QUERY_DONE,      /* *out has fresh data                            */
    BMS_QUERY_TIMEOUT    /* all attempts used up with no valid reply       */
} bms_query_state_t;

/** Start a new query (request goes out immediately). */
void bms_query_start(uint32_t now_ms);

/**
 * Advance the query. Call often from the main loop with a ms tick.
 * Handles the 500 ms timeout and the retry transparently.
 */
bms_query_state_t bms_query_poll(uint32_t now_ms, bms_reading_t *out);

#endif /* BMS_PROTOCOL_H */
