/**
 * can_driver.h - thin CAN (bxCAN) driver for the STM32F103.
 *
 * Knows nothing about the Daly protocol: it only opens the bus at 250 kbit/s
 * and moves 29-bit extended frames in and out. The BMS layer (bms_protocol.c)
 * is written purely against this header, so it can be unit-tested on a PC with
 * a mock implementation (tests/mock_can.c).
 */
#ifndef CAN_DRIVER_H
#define CAN_DRIVER_H

#include <stdint.h>
#include <stdbool.h>

#define CAN_DRV_MAX_DLC 8u

typedef struct {
    uint32_t ext_id;                 /* 29-bit identifier */
    uint8_t  dlc;                    /* 0..8 */
    uint8_t  data[CAN_DRV_MAX_DLC];
} can_frame_t;

typedef enum {
    CAN_DRV_OK = 0,
    CAN_DRV_ERR_INIT,
    CAN_DRV_ERR_BUSY,    /* no free TX mailbox */
    CAN_DRV_ERR_ARG,
    CAN_DRV_ERR_HAL
} can_status_t;

/**
 * Start the peripheral: 250 kbit/s, extended IDs, auto bus-off recovery.
 * Only frames whose 29-bit ID equals rx_id are let through the hardware
 * filter (everything else on the bus is ignored without CPU load).
 */
can_status_t can_driver_init(uint32_t rx_id);

/** Queue one extended-ID data frame for transmission (non-blocking). */
can_status_t can_driver_send(const can_frame_t *frame);

/** Fetch one received frame if available (non-blocking). true = frame returned. */
bool can_driver_receive(can_frame_t *frame);

/** Drop anything waiting in the RX FIFO (used before each new request). */
void can_driver_flush_rx(void);

/** Cancel frames still waiting in the TX mailboxes (e.g. nobody ACKs). */
void can_driver_abort_tx(void);

#endif /* CAN_DRIVER_H */
