#ifndef MOCK_CAN_H
#define MOCK_CAN_H
#include "can_driver.h"
/* test hooks */
extern int  mock_tx_count;
extern can_frame_t mock_last_tx;
extern int  mock_abort_count;
void mock_can_reset(void);
void mock_can_push_rx(const can_frame_t *f);
#endif
