#include "mock_can.h"
#include <string.h>

int mock_tx_count, mock_abort_count;
can_frame_t mock_last_tx;
static can_frame_t rxq[8];
static int rx_n;

void mock_can_reset(void) { mock_tx_count = mock_abort_count = rx_n = 0; memset(&mock_last_tx, 0, sizeof mock_last_tx); }
void mock_can_push_rx(const can_frame_t *f) { rxq[rx_n++] = *f; }

can_status_t can_driver_init(uint32_t id) { (void)id; return CAN_DRV_OK; }
can_status_t can_driver_send(const can_frame_t *f) { mock_last_tx = *f; mock_tx_count++; return CAN_DRV_OK; }
bool can_driver_receive(can_frame_t *f)
{
    if (!rx_n) return false;
    *f = rxq[0];
    memmove(&rxq[0], &rxq[1], sizeof(can_frame_t) * (size_t)(--rx_n));
    return true;
}
void can_driver_flush_rx(void) { rx_n = 0; }
void can_driver_abort_tx(void) { mock_abort_count++; }
