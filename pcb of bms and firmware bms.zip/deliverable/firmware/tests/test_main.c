#include <stdio.h>
#include <string.h>
#include "bms_protocol.h"
#include "esp_link.h"
#include "mock_can.h"

static int fails, checks;
#define CHECK(c) do { checks++; if (!(c)) { fails++; printf("FAIL line %d: %s\n", __LINE__, #c); } } while (0)

static can_frame_t reply(const uint8_t d[8])
{
    can_frame_t f = { .ext_id = BMS_RESPONSE_ID, .dlc = 8 };
    memcpy(f.data, d, 8);
    return f;
}

static void test_request(void)
{
    can_frame_t f; bms_build_request(&f);
    CHECK(f.ext_id == 0x18900140UL);
    CHECK(f.dlc == 8);
    for (int i = 0; i < 8; i++) CHECK(f.data[i] == 0);
}

static void test_decode(void)
{
    bms_reading_t r;
    /* worked example from the Excel decoder: 53.2 V, 53.0 V, 0.0 A, 100 % */
    const uint8_t ex[8] = {0x02,0x14,0x02,0x12,0x75,0x30,0x03,0xE8};
    can_frame_t f = reply(ex);
    CHECK(bms_decode_0x90(&f, &r));
    CHECK(r.voltage_dv == 532 && r.current_da == 0 && r.soc_pm == 1000);

    /* raw 29500 (0x733C) -> -50.0 A, as stated in the Excel sheet */
    const uint8_t neg[8] = {0x02,0x14,0x02,0x12,0x73,0x3C,0x03,0xE8};
    f = reply(neg); CHECK(bms_decode_0x90(&f, &r)); CHECK(r.current_da == -500);

    /* 30123 -> +12.3 A ; 29877 -> -12.3 A */
    const uint8_t p[8] = {0x02,0x14,0,0,0x75,0xAB,0,0};   /* 0x75AB = 30123 */
    f = reply(p); CHECK(bms_decode_0x90(&f, &r)); CHECK(r.current_da == 123);
    const uint8_t n[8] = {0x02,0x14,0,0,0x74,0xB5,0,0};   /* 0x74B5 = 29877 */
    f = reply(n); CHECK(bms_decode_0x90(&f, &r)); CHECK(r.current_da == -123);

    /* rejects wrong ID / wrong DLC */
    f = reply(ex); f.ext_id = 0x18904002UL; CHECK(!bms_decode_0x90(&f, &r));
    f = reply(ex); f.dlc = 7;               CHECK(!bms_decode_0x90(&f, &r));
}

static void test_format(void)
{
    char b[ESP_LINK_LINE_MAX];
    size_t n;
    n = esp_link_format_data(b, sizeof b, 532, -123);
    CHECK(n && strcmp(b, "{\"voltage\":53.2, \"current\":-12.3}\n") == 0);
    n = esp_link_format_data(b, sizeof b, 1000, 0);
    CHECK(strcmp(b, "{\"voltage\":100.0, \"current\":0.0}\n") == 0);
    n = esp_link_format_data(b, sizeof b, 5, -5);
    CHECK(strcmp(b, "{\"voltage\":0.5, \"current\":-0.5}\n") == 0);
    /* worst case: max raw 65535 -> 6553.5 V ; current -30000..+35535 -> -3000.0..3553.5 A */
    n = esp_link_format_data(b, sizeof b, 65535, -30000);
    CHECK(strcmp(b, "{\"voltage\":6553.5, \"current\":-3000.0}\n") == 0);
    CHECK(n < ESP_LINK_LINE_MAX);
    CHECK(esp_link_format_data(b, 10, 532, 0) == 0);          /* too small buffer */
    n = esp_link_format_timeout(b, sizeof b);
    CHECK(n && strcmp(b, "{\"error\":\"bms_timeout\"}\n") == 0);
}

static void test_query(void)
{
    bms_reading_t r;
    const uint8_t ex[8] = {0x02,0x14,0x02,0x12,0x75,0x30,0x03,0xE8};

    /* 1) reply arrives at once */
    mock_can_reset();
    bms_query_start(1000);
    CHECK(mock_tx_count == 1 && mock_last_tx.ext_id == BMS_REQUEST_ID);
    can_frame_t f = reply(ex); mock_can_push_rx(&f);
    CHECK(bms_query_poll(1002, &r) == BMS_QUERY_DONE && r.voltage_dv == 532);

    /* 2) first attempt silent, retry after 500 ms succeeds */
    mock_can_reset();
    bms_query_start(2000);
    CHECK(bms_query_poll(2499, &r) == BMS_QUERY_PENDING && mock_tx_count == 1);
    CHECK(bms_query_poll(2500, &r) == BMS_QUERY_PENDING && mock_tx_count == 2);   /* retry */
    mock_can_push_rx(&f);
    CHECK(bms_query_poll(2600, &r) == BMS_QUERY_DONE);

    /* 3) no reply at all -> timeout after 2 x 500 ms, exactly 2 requests */
    mock_can_reset();
    bms_query_start(3000);
    CHECK(bms_query_poll(3500, &r) == BMS_QUERY_PENDING);
    CHECK(bms_query_poll(3999, &r) == BMS_QUERY_PENDING);
    CHECK(bms_query_poll(4000, &r) == BMS_QUERY_TIMEOUT);
    CHECK(mock_tx_count == 2);

    /* 4) junk frame (wrong ID) is ignored, timer keeps running */
    mock_can_reset();
    bms_query_start(5000);
    can_frame_t junk = f; junk.ext_id = 0x18904002UL; mock_can_push_rx(&junk);
    CHECK(bms_query_poll(5100, &r) == BMS_QUERY_PENDING);

    /* 5) tick counter wrap-around */
    mock_can_reset();
    bms_query_start(0xFFFFFF00u);
    CHECK(bms_query_poll(0xFFFFFF00u + 499u, &r) == BMS_QUERY_PENDING && mock_tx_count == 1);
    CHECK(bms_query_poll(0xFFFFFF00u + 500u, &r) == BMS_QUERY_PENDING && mock_tx_count == 2);
}

int main(void)
{
    test_request(); test_decode(); test_format(); test_query();
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
